﻿using System;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Runtime.CompilerServices;
using System.Threading;
using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;
using Org.BouncyCastle.Asn1.Cms;

namespace Sendmes
{
    class Program
    {



        static bool jdj_day(string args)
        {

            if (args.Length < 6)
                return false;

            // 解析文件名中的日期部分
            string datePart = args.Substring(0, 6);
            if (!DateTime.TryParseExact(datePart, "yyMMdd", null, System.Globalization.DateTimeStyles.None, out DateTime fileDate))
            {
                // 如解析失败，表示格式不正确
                return false;
            }

            // 计算时间差值
            var daysDifference = (DateTime.Now - fileDate).TotalDays;

            // 如果超过我们设定的天数阈值，则认为应被归档
            return daysDifference > 7;


        }

        static void Main(string[] args)
        {
            if (IsInternetAvailable())
            {
                Htmlsupport htmlsupport = new Htmlsupport();


                SendEmailWithFolderContents();
            }
            else
            {
                Console.WriteLine("No Internet connection available. Retrying in 30 seconds...");
                Thread.Sleep(30000); // 30秒的休眠时间

                Console.WriteLine("Retrying now...");
                if (IsInternetAvailable())
                {
                    SendEmailWithFolderContents();
                }
                else
                {
                    Console.WriteLine("Still no Internet connection. Exiting.");

                }
            }
        }

        static bool IsInternetAvailable()
        {
            try
            {
                using (var ping = new Ping())
                {
                    var reply = ping.Send("8.8.8.8", 3000); // 3秒的超时
                    return reply.Status == IPStatus.Success;
                }
            }
            catch
            {
                return false;
            }
        }

        static void SendEmailWithFolderContents()
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string[] targetFolders = { "", "Bob" };

            string smtpServer = "smtp.qq.com";
            int smtpPort = 465;  // SSL 端口
            string smtpUser = "3450462398@qq.com";
            string smtpPassword = "dgqkxcsjlxxrdcab"; 
            string recipient = "23251328@bjtu.edu.cn";

            var folders = Directory.GetDirectories(desktopPath)
                .Where(folder => jdj_day(Path.GetFileName(folder)))
                //.Where(dir => targetFolders.Any(keyword => Path.GetFileName(dir).Contains(keyword)))
                .ToList();

            if (folders.Any())
            {



                string templatePath = "iMeg.html";
                string htmlTemplate = Htmlsupport.LoadTemplate(templatePath);

                string fileListHtml = string.Join("", folders.Select(folder => $"<li>{Path.GetFileName(folder)}</li>"));
                string htmlBody = Htmlsupport.FillTemplate(htmlTemplate, fileListHtml);


                var email = new MimeMessage();
                email.From.Add(MailboxAddress.Parse(smtpUser));
                email.To.Add(MailboxAddress.Parse(recipient));
                email.Subject = "Notification!";

                email.Body = new TextPart("html") { Text = htmlBody };

                //string body = "Unclassified files:\n" + string.Join("\n", folders);
                //email.Body = new TextPart("plain") { Text = body };

                using (var smtpClient = new SmtpClient())
                {
                    int retries = 3;
                    while (retries > 0)
                    {
                        try
                        {
                            smtpClient.Connect(smtpServer, smtpPort, SecureSocketOptions.SslOnConnect);
                            Console.WriteLine("SMTP服务器连接状态：" + smtpClient.IsConnected);

                            smtpClient.Authenticate(smtpUser, smtpPassword);
                            Console.WriteLine("SSL验证状态：" + smtpClient.IsAuthenticated);

                            smtpClient.Send(email);
                            Console.WriteLine("Email sent successfully.");
                            break; // 成功后跳出循环
                        }
                        catch (Exception ex)
                        {
                            retries--;
                            Console.WriteLine($"Failed to send email: {ex.Message}. Retries left: {retries}");
                            if (retries == 0)
                            {
                                Console.WriteLine("All retries failed.");
                                Console.ReadKey();
                            }
                        }
                        finally
                        {
                            smtpClient.Disconnect(true);
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("No target folders found.");
                Console.ReadKey();
            }
        }
    }
}